package nl.inholland.guitarshopapi.model;

public enum Role {
  USER,ADMIN
}
