package nl.inholland.guitarshopapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuitarshopApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
